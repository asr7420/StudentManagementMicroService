package com.example.microservice_project;

import jakarta.persistence.*;
import jakarta.validation.constraints.Email;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
@Entity
@Data
@AllArgsConstructor
@NoArgsConstructor
public class entity {
@Id
@GeneratedValue(strategy = GenerationType.IDENTITY)
    private int rollno;

    private String name;
    @Email
    @Column(unique = true)
    private String email_id;
    @Column(unique = true)
    private long ph_no;
    public entity(String name,String email_id,long ph_no){
        this.name=name;
        this.email_id=email_id;
        this.ph_no=ph_no;
    }
}
