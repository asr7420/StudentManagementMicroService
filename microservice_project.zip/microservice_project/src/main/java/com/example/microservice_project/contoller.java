package com.example.microservice_project;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/student")
public class contoller {
    @Autowired
    private service serv;
    @PostMapping("/add")
    public entity addstudent(@RequestBody entity studentdata){
        return serv.savestudent(studentdata);
    }
    @GetMapping("/all")
        public List<entity> findall(){
            return serv.getstudent();
        }

        @GetMapping("/all/{id}")
    public entity getbyid(@PathVariable int id){
        return serv.byid(id);
        }

        @PutMapping("/put")
    public entity update(@RequestBody entity update){
        return serv.update(update);
        }

        @DeleteMapping("/delete/{id}")
public String delete(@PathVariable int id){
return serv.delete(id);
        }

}
