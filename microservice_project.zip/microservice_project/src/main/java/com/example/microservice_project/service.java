package com.example.microservice_project;

import jakarta.persistence.Entity;
import org.jspecify.annotations.NonNull;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class service {
    @Autowired
    private repository repo;
//post wali request
    public entity savestudent(entity student){
        return repo.save(student);
    }
    //get wali request
    public List<entity> getstudent(){
        return repo.findAll();
    }

    //rollno se retrieve krna
    public entity byid(int id){
        return repo.findById(id).orElse(null);
    }
    //update krna
    public entity update(@NonNull entity student){
        entity existingstudent=repo.findById(student.getRollno()).orElse(null);
        if(existingstudent==null){
            return null;
        }
        existingstudent.setName(student.getName());
        existingstudent.setEmail_id(student.getEmail_id());
        existingstudent.setPh_no(student.getPh_no());
        return repo.save(existingstudent);
    }
    //delete krna
    public String delete(int id){
        repo.deleteById(id);
        return "the data corresponding to the "+ id +"have been deleted";
    }

}
